
package com.studyhub.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

private val studySections = listOf(
    "Notes",
    "Question Banks",
    "Numericals",
    "Tests",
    "Assignments",
    "References",
    "Other"
)

private val studyUnits = (1..5).map { "Unit $it" }

private val studySubjects = mapOf(
    1 to listOf(
        "Engineering Physics",
        "Engineering Mathematics",
        "Engineering Graphics",
        "Fundamentals of Programming Language",
        "Basic Electrical Engineering"
    ),
    2 to listOf(
        "Engineering Chemistry",
        "Engineering Mathematics",
        "Mechanics and Robotics",
        "Fundamentals of Programming Language",
        "Basic Electrical Engineering"
    )
)

private val subjectSymbols = mapOf(
    "Engineering Physics" to "⚛",
    "Engineering Chemistry" to "⚗",
    "Engineering Mathematics" to "∑",
    "Engineering Graphics" to "📐",
    "Mechanics and Robotics" to "⚙",
    "Fundamentals of Programming Language" to "</>",
    "Basic Electrical Engineering" to "ϟ"
)

private data class StudyFile(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val subject: String,
    val semester: Int,
    val section: String,
    val unit: String,
    val uri: String
)

private class StudyStorage(context: Context) {
    private val prefs = context.getSharedPreferences(
        "studyhub_data",
        Context.MODE_PRIVATE
    )

    fun read(): List<StudyFile> {
        return try {
            val array = JSONArray(prefs.getString("files", "[]"))
            (0 until array.length()).map { i ->
                val o = array.getJSONObject(i)
                StudyFile(
                    id = o.optString("id", UUID.randomUUID().toString()),
                    title = o.optString("title", "Study material"),
                    subject = o.optString("subject", ""),
                    semester = o.optInt("semester", 1),
                    section = o.optString("section", "Notes"),
                    unit = o.optString("unit", "Unit 1"),
                    uri = o.optString("uri", "")
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun write(files: List<StudyFile>) {
        val array = JSONArray()
        files.forEach { file ->
            array.put(JSONObject().apply {
                put("id", file.id)
                put("title", file.title)
                put("subject", file.subject)
                put("semester", file.semester)
                put("section", file.section)
                put("unit", file.unit)
                put("uri", file.uri)
            })
        }
        prefs.edit().putString("files", array.toString()).apply()
    }

    fun saveTheme(dark: Boolean) {
        prefs.edit().putBoolean("dark_theme", dark).apply()
    }

    fun readTheme(): Boolean =
        prefs.getBoolean("dark_theme", true)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            StudyHubApp()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StudyHubApp() {
    val context = LocalContext.current
    val storage = remember { StudyStorage(context.applicationContext) }

    var files by remember { mutableStateOf(storage.read()) }
    var darkTheme by remember { mutableStateOf(storage.readTheme()) }

    var semester by remember { mutableIntStateOf(1) }
    var selectedSubject by remember { mutableStateOf<String?>(null) }
    var selectedSection by remember { mutableStateOf<String?>(null) }
    var selectedUnit by remember { mutableStateOf<String?>(null) }

    var showAddDialog by remember { mutableStateOf(false) }
    var titleInput by remember { mutableStateOf("") }

    val subjects = studySubjects[semester] ?: emptyList()

    val currentScreen = when {
        selectedSubject == null -> "home"
        selectedSection == null -> "subject"
        selectedUnit == null -> "section"
        else -> "unit"
    }

    BackHandler(enabled = currentScreen != "home") {
        when (currentScreen) {
            "unit" -> selectedUnit = null
            "section" -> selectedSection = null
            "subject" -> selectedSubject = null
        }
    }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {
                // Some providers do not support persisted URI permissions.
            }

            val subject = selectedSubject
            val section = selectedSection
            val unit = selectedUnit

            if (subject != null && section != null && unit != null) {
                val newFile = StudyFile(
                    title = titleInput.trim().ifBlank {
                        getStudyFileName(context, uri)
                    },
                    subject = subject,
                    semester = semester,
                    section = section,
                    unit = unit,
                    uri = uri.toString()
                )

                files = listOf(newFile) + files
                storage.write(files)
                titleInput = ""
                showAddDialog = false

                Toast.makeText(
                    context,
                    "Material added successfully",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    MaterialTheme(
        colorScheme = if (darkTheme) darkColorScheme() else lightColorScheme()
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                "StudyHub",
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "Your personal study library",
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    },
                    navigationIcon = {
                        if (currentScreen != "home") {
                            TextButton(
                                onClick = {
                                    when (currentScreen) {
                                        "unit" -> selectedUnit = null
                                        "section" -> selectedSection = null
                                        "subject" -> selectedSubject = null
                                    }
                                }
                            ) {
                                Text("‹", style = MaterialTheme.typography.headlineLarge)
                            }
                        }
                    },
                    actions = {
                        TextButton(
                            onClick = {
                                darkTheme = !darkTheme
                                storage.saveTheme(darkTheme)
                            }
                        ) {
                            Text(if (darkTheme) "☀" else "☾")
                        }
                    }
                )
            },
            floatingActionButton = {
                if (currentScreen == "unit") {
                    FloatingActionButton(
                        onClick = {
                            titleInput = ""
                            showAddDialog = true
                        }
                    ) {
                        Text("+", style = MaterialTheme.typography.headlineMedium)
                    }
                }
            }
        ) { padding ->

            // HOME: only semester controls and subject cards.
            if (currentScreen == "home") {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(horizontal = 16.dp)
                ) {
                    Spacer(Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(1, 2).forEach { sem ->
                            FilterChip(
                                selected = semester == sem,
                                onClick = {
                                    semester = sem
                                    selectedSubject = null
                                    selectedSection = null
                                    selectedUnit = null
                                },
                                label = { Text("Semester $sem") }
                            )
                        }
                    }

                    Text(
                        "Your subjects",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(
                            top = 14.dp,
                            bottom = 10.dp
                        )
                    )

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 24.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(subjects) { subject ->
                            val count = files.count {
                                it.semester == semester && it.subject == subject
                            }

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedSubject = subject
                                        selectedSection = null
                                        selectedUnit = null
                                    },
                                shape = RoundedCornerShape(18.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                                )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(18.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(14.dp),
                                        color = MaterialTheme.colorScheme.primaryContainer,
                                        modifier = Modifier.size(54.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                subjectSymbols[subject] ?: "📘",
                                                style = MaterialTheme.typography.titleLarge,
                                                color = MaterialTheme.colorScheme.onPrimaryContainer
                                            )
                                        }
                                    }

                                    Spacer(Modifier.width(14.dp))

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            subject,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Spacer(Modifier.height(4.dp))
                                        Text(
                                            "$count materials",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    Text(
                                        "›",
                                        style = MaterialTheme.typography.headlineMedium,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // SUBJECT: display section cards.
            else if (currentScreen == "subject") {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(horizontal = 16.dp)
                ) {
                    Text(
                        selectedSubject ?: "",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )

                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(bottom = 24.dp)
                    ) {
                        items(studySections) { section ->
                            val count = files.count {
                                it.semester == semester &&
                                it.subject == selectedSubject &&
                                it.section == section
                            }

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedSection = section
                                        selectedUnit = null
                                    },
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(18.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            section,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            "$count materials",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Text(
                                        "›",
                                        style = MaterialTheme.typography.headlineMedium
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // SECTION: display Unit 1 through Unit 5.
            else if (currentScreen == "section") {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(horizontal = 16.dp)
                ) {
                    Text(
                        selectedSection ?: "",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)
                    )
                    Text(
                        selectedSubject ?: "",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 14.dp)
                    )

                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(bottom = 24.dp)
                    ) {
                        items(studyUnits) { unit ->
                            val count = files.count {
                                it.semester == semester &&
                                it.subject == selectedSubject &&
                                it.section == selectedSection &&
                                it.unit == unit
                            }

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedUnit = unit },
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(18.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            unit,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            "$count files",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Text(
                                        "›",
                                        style = MaterialTheme.typography.headlineMedium
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // UNIT: show files stored in this exact location.
            else {
                val visibleFiles = files.filter {
                    it.semester == semester &&
                    it.subject == selectedSubject &&
                    it.section == selectedSection &&
                    it.unit == selectedUnit
                }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(horizontal = 16.dp)
                ) {
                    Text(
                        selectedUnit ?: "",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)
                    )

                    Text(
                        "${selectedSubject} · ${selectedSection}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 14.dp)
                    )

                    if (visibleFiles.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("📂", style = MaterialTheme.typography.displaySmall)
                                Spacer(Modifier.height(10.dp))
                                Text(
                                    "No materials yet",
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    "Tap + to add a file to this unit.",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(bottom = 100.dp)
                        ) {
                            items(visibleFiles, key = { it.id }) { file ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp)
                                    ) {
                                        Text(
                                            file.title,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.SemiBold
                                        )

                                        Spacer(Modifier.height(8.dp))

                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            OutlinedButton(
                                                onClick = {
                                                    openStudyFile(context, file.uri)
                                                }
                                            ) {
                                                Text("Open file")
                                            }

                                            TextButton(
                                                onClick = {
                                                    files = files.filterNot {
                                                        it.id == file.id
                                                    }
                                                    storage.write(files)
                                                }
                                            ) {
                                                Text(
                                                    "Delete",
                                                    color = MaterialTheme.colorScheme.error
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showAddDialog) {
            AlertDialog(
                onDismissRequest = { showAddDialog = false },
                title = { Text("Add study material") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(selectedSubject ?: "")
                        Text("${selectedSection} · ${selectedUnit}")

                        OutlinedTextField(
                            value = titleInput,
                            onValueChange = { titleInput = it },
                            label = { Text("File title (optional)") },
                            singleLine = true
                        )

                        Text(
                            "Choose a PDF, Word document, PowerPoint, or text file.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            filePicker.launch(
                                arrayOf(
                                    "application/pdf",
                                    "application/msword",
                                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                    "application/vnd.ms-powerpoint",
                                    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                                    "text/plain"
                                )
                            )
                        }
                    ) {
                        Text("Choose file")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

private fun getStudyFileName(context: Context, uri: Uri): String {
    var name = uri.lastPathSegment ?: "Study material"

    try {
        context.contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) {
                    name = cursor.getString(index) ?: name
                }
            }
        }
    } catch (_: Exception) {
        // Use fallback name.
    }

    return name
}

private fun openStudyFile(context: Context, uriString: String) {
    try {
        val uri = Uri.parse(uriString)
        val mime = context.contentResolver.getType(uri) ?: "*/*"

        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        context.startActivity(intent)
    } catch (_: Exception) {
        Toast.makeText(
            context,
            "No compatible app could open this file.",
            Toast.LENGTH_LONG
        ).show()
    }
}
